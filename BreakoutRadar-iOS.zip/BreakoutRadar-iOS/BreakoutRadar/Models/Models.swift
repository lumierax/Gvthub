import Foundation

enum TradeDirection: String, Codable, Sendable, CaseIterable {
    case long = "LONG"
    case short = "SHORT"
    case neutral = "NEUTRAL"
}

struct Candle: Identifiable, Hashable, Sendable {
    let openTime: Date
    let closeTime: Date
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    let volume: Double

    var id: Date { openTime }
}

struct CandleMetrics: Sendable {
    let bodyRatio: Double
    let upperWickRatio: Double
    let lowerWickRatio: Double
    let isBullish: Bool
}

struct ScanResult: Identifiable, Hashable, Sendable {
    let symbol: String
    let price: Double
    let volume: Double
    let score: Int
    let direction: TradeDirection
    let flags: [String]
    let zScore: Double
    let bbw: Double
    let deltaOI: Double
    let updatedAt: Date

    var id: String { symbol }

    var displaySymbol: String {
        symbol.hasSuffix("USDT") ? String(symbol.dropLast(4)) : symbol
    }

    func status(using config: RadarConfig) -> String {
        if score >= config.sniperScore { return "SNIPER" }
        if score >= config.watchlistScore { return "WATCHLIST" }
        return "SETUP"
    }
}

struct CandidateTicker: Sendable {
    let symbol: String
    let quoteVolume: Double
    let priceChangePercent: Double
    let lastPrice: Double
}

enum ScanFilter: String, CaseIterable, Identifiable {
    case all = "الكل"
    case long = "صاعد"
    case short = "هابط"

    var id: String { rawValue }
}
