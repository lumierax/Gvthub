import Foundation

struct BreakoutScoringEngine: Sendable {
    let config: RadarConfig

    init(config: RadarConfig = RadarConfig()) {
        self.config = config
    }

    func evaluate(symbol: String, candles: [Candle], historicalOI: [Double]) -> ScanResult? {
        guard candles.count >= config.lookbackPeriods else { return nil }

        let window = Array(candles.suffix(config.lookbackPeriods))
        let closes = window.map(\.close)
        let highs = window.map(\.high)
        let lows = window.map(\.low)
        let volumes = window.map(\.volume)
        guard let current = window.last else { return nil }

        let bandwidths = Indicators.bollingerBandwidths(
            closes: closes,
            period: config.bbPeriod,
            standardDeviations: config.bbStandardDeviations
        )
        let currentBBW = bandwidths.last.flatMap { $0 } ?? 0
        let recentBBW = bandwidths.suffix(10).compactMap { $0 }
        let minimumRecentBBW = recentBBW.min() ?? .infinity
        let isCompressed = minimumRecentBBW <= config.bbwCompressionThreshold

        let zScore = Indicators.volumeZScore(volumes: volumes, period: config.lookbackPeriods)
        let deltaOI = Indicators.deltaOpenInterest(historicalOI)
        let candleMetrics = Indicators.candleMetrics(
            open: current.open,
            high: current.high,
            low: current.low,
            close: current.close
        )

        guard
            let smaFast = Indicators.simpleMovingAverage(closes, period: config.smaFast),
            let smaSlow = Indicators.simpleMovingAverage(closes, period: config.smaSlow)
        else { return nil }

        let priorHighs = highs.dropLast()
        let priorLows = lows.dropLast()
        guard let lookbackHigh = priorHighs.max(), let lookbackLow = priorLows.min() else { return nil }

        let long = scoreDirection(
            direction: .long,
            isCompressed: isCompressed,
            zScore: zScore,
            deltaOI: deltaOI,
            candleMetrics: candleMetrics,
            isTrendAligned: smaFast > smaSlow,
            isBreakingLevel: current.close >= lookbackHigh * 0.998
        )

        let short = scoreDirection(
            direction: .short,
            isCompressed: isCompressed,
            zScore: zScore,
            deltaOI: deltaOI,
            candleMetrics: candleMetrics,
            isTrendAligned: smaFast < smaSlow,
            isBreakingLevel: current.close <= lookbackLow * 1.002
        )

        let selected: (direction: TradeDirection, score: Int, flags: [String])
        if long.score >= short.score && long.score > 0 {
            selected = (.long, long.score, long.flags)
        } else if short.score > long.score && short.score > 0 {
            selected = (.short, short.score, short.flags)
        } else {
            selected = (.neutral, 0, [])
        }

        return ScanResult(
            symbol: symbol,
            price: current.close,
            volume: current.volume,
            score: selected.score,
            direction: selected.direction,
            flags: selected.flags,
            zScore: zScore,
            bbw: currentBBW,
            deltaOI: deltaOI,
            updatedAt: Date()
        )
    }

    private func scoreDirection(
        direction: TradeDirection,
        isCompressed: Bool,
        zScore: Double,
        deltaOI: Double,
        candleMetrics: CandleMetrics,
        isTrendAligned: Bool,
        isBreakingLevel: Bool
    ) -> (score: Int, flags: [String]) {
        var score = 0
        var flags: [String] = []

        if isCompressed {
            score += config.weightCompression
            flags.append("COILED")
        }

        if zScore >= config.volumeZScoreTrigger {
            score += config.weightVolumeSpike
            flags.append("VOL_SPIKE")
        }

        if deltaOI >= config.deltaOIThresholdPercent {
            score += config.weightDeltaOI
            flags.append("OI_EXPANSION")
        }

        if isTrendAligned {
            score += config.weightTrendAlignment
        }

        let wickOK: Bool
        let directionalCandleOK: Bool
        switch direction {
        case .long:
            wickOK = candleMetrics.upperWickRatio <= config.maxRejectionWickRatio
            directionalCandleOK = candleMetrics.isBullish
        case .short:
            wickOK = candleMetrics.lowerWickRatio <= config.maxRejectionWickRatio
            directionalCandleOK = !candleMetrics.isBullish
        case .neutral:
            wickOK = false
            directionalCandleOK = false
        }

        if candleMetrics.bodyRatio >= config.candleBodyMinimumRatio && wickOK && directionalCandleOK {
            score += config.weightCandleQuality
            flags.append("STRONG_BODY")
        }

        if !isBreakingLevel {
            score = Int(Double(score) * 0.5)
        }

        return (min(score, 100), flags)
    }
}
