import Foundation

struct RadarConfig: Sendable {
    var klineInterval: String = "15m"
    var lookbackPeriods: Int = 50
    var openInterestPeriod: String = "15m"
    var openInterestLimit: Int = 5

    var min24hQuoteVolume: Double = 15_000_000
    var maxSymbolsTracked: Int = 40
    var refreshSeconds: UInt64 = 45

    var bbPeriod: Int = 20
    var bbStandardDeviations: Double = 2.0
    var bbwCompressionThreshold: Double = 0.03
    var volumeZScoreTrigger: Double = 3.0
    var deltaOIThresholdPercent: Double = 2.0
    var smaFast: Int = 7
    var smaSlow: Int = 25
    var maxRejectionWickRatio: Double = 0.60
    var candleBodyMinimumRatio: Double = 0.70

    var weightCompression: Int = 20
    var weightVolumeSpike: Int = 25
    var weightDeltaOI: Int = 15
    var weightTrendAlignment: Int = 15
    var weightCandleQuality: Int = 15

    var watchlistScore: Int = 55
    var sniperScore: Int = 75
    var displayMinimumScore: Int = 25

    var blacklist: Set<String> = [
        "USDCUSDT", "BUSDUSDT", "TUSDUSDT", "USDPUSDT", "FDUSDUSDT"
    ]
}
