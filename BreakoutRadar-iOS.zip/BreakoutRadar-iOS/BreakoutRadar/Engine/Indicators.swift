import Foundation

enum Indicators {
    static func mean(_ values: ArraySlice<Double>) -> Double {
        guard !values.isEmpty else { return 0 }
        return values.reduce(0, +) / Double(values.count)
    }

    /// Sample standard deviation, matching pandas Series.std() (ddof = 1).
    static func sampleStandardDeviation(_ values: ArraySlice<Double>) -> Double {
        guard values.count > 1 else { return 0 }
        let avg = mean(values)
        let squared = values.reduce(0.0) { partial, value in
            partial + pow(value - avg, 2)
        }
        return sqrt(squared / Double(values.count - 1))
    }

    static func simpleMovingAverage(_ values: [Double], period: Int) -> Double? {
        guard period > 0, values.count >= period else { return nil }
        return mean(values.suffix(period))
    }

    static func bollingerBandwidths(
        closes: [Double],
        period: Int,
        standardDeviations: Double
    ) -> [Double?] {
        guard period > 1 else { return Array(repeating: nil, count: closes.count) }

        var output = Array<Double?>(repeating: nil, count: closes.count)
        guard closes.count >= period else { return output }

        for end in (period - 1)..<closes.count {
            let start = end - period + 1
            let window = closes[start...end]
            let basis = mean(window)
            guard basis != 0 else {
                output[end] = nil
                continue
            }
            let std = sampleStandardDeviation(window)
            let dev = standardDeviations * std
            let upper = basis + dev
            let lower = basis - dev
            output[end] = (upper - lower) / basis
        }
        return output
    }

    /// Mirrors the Python implementation: compare the current volume against the
    /// previous `period - 1` observations within a `period`-bar window.
    static func volumeZScore(volumes: [Double], period: Int) -> Double {
        guard period >= 2, volumes.count >= period else { return 0 }
        let start = volumes.count - period
        let historical = volumes[start..<(volumes.count - 1)]
        let historicalMean = mean(historical)
        let historicalStd = sampleStandardDeviation(historical)
        let current = volumes[volumes.count - 1]

        if historicalStd == 0 || historicalStd.isNaN {
            if current == historicalMean { return 0 }
            return current > historicalMean ? 10 : -10
        }
        return (current - historicalMean) / historicalStd
    }

    static func candleMetrics(open: Double, high: Double, low: Double, close: Double) -> CandleMetrics {
        let range = high - low
        guard range > 0 else {
            return CandleMetrics(bodyRatio: 0, upperWickRatio: 0, lowerWickRatio: 0, isBullish: false)
        }
        let body = abs(close - open)
        let upperWick = high - max(open, close)
        let lowerWick = min(open, close) - low
        return CandleMetrics(
            bodyRatio: body / range,
            upperWickRatio: upperWick / range,
            lowerWickRatio: lowerWick / range,
            isBullish: close > open
        )
    }

    static func deltaOpenInterest(_ values: [Double]) -> Double {
        guard values.count >= 2 else { return 0 }
        let previous = values[values.count - 2]
        guard previous != 0 else { return 0 }
        let current = values[values.count - 1]
        return ((current - previous) / previous) * 100
    }
}
