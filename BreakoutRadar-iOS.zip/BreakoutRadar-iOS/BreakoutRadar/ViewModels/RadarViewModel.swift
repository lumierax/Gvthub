import Combine
import Foundation

@MainActor
final class RadarViewModel: ObservableObject {
    @Published private(set) var results: [ScanResult] = []
    @Published private(set) var isScanning = false
    @Published private(set) var scannedCount = 0
    @Published private(set) var totalCount = 0
    @Published private(set) var lastUpdated: Date?
    @Published var errorMessage: String?
    @Published var filter: ScanFilter = .all
    @Published var searchText = ""
    @Published var autoRefresh = true
    @Published var includeLiveCandle = false
    let baseConfig = RadarConfig()

    private let scanner = MarketScanner()
    private var refreshTask: Task<Void, Never>?
    private var scanTask: Task<Void, Never>?

    var config: RadarConfig { baseConfig }

    var visibleResults: [ScanResult] {
        results.filter { result in
            let matchesDirection: Bool
            switch filter {
            case .all: matchesDirection = true
            case .long: matchesDirection = result.direction == .long
            case .short: matchesDirection = result.direction == .short
            }

            let matchesSearch = searchText.isEmpty || result.symbol.localizedCaseInsensitiveContains(searchText)
            return matchesDirection && matchesSearch
        }
    }

    var sniperCount: Int { results.filter { $0.score >= config.sniperScore }.count }
    var watchlistCount: Int {
        results.filter { $0.score >= config.watchlistScore && $0.score < config.sniperScore }.count
    }

    func start() {
        guard refreshTask == nil else { return }
        refreshTask = Task { [weak self] in
            guard let self else { return }
            await self.scanNow()
            while !Task.isCancelled {
                let seconds = self.config.refreshSeconds
                try? await Task.sleep(nanoseconds: seconds * 1_000_000_000)
                guard !Task.isCancelled else { break }
                if self.autoRefresh {
                    await self.scanNow()
                }
            }
        }
    }

    func stop() {
        refreshTask?.cancel()
        refreshTask = nil
        scanTask?.cancel()
        scanTask = nil
    }

    func scanNow() async {
        if isScanning { return }
        isScanning = true
        errorMessage = nil
        scannedCount = 0
        totalCount = 0

        let currentConfig = config
        let live = includeLiveCandle

        scanTask = Task { [weak self] in
            guard let self else { return }
            do {
                let output = try await scanner.scan(
                    config: currentConfig,
                    includeLiveCandle: live,
                    progress: { completed, total in
                        await MainActor.run {
                            self.scannedCount = completed
                            self.totalCount = total
                        }
                    }
                )
                guard !Task.isCancelled else { return }
                self.results = output
                self.lastUpdated = Date()
            } catch {
                guard !Task.isCancelled else { return }
                self.errorMessage = error.localizedDescription
            }
            self.isScanning = false
        }
        await scanTask?.value
    }

    func applySettingsAndRescan() {
        Task { await scanNow() }
    }
}
