import Foundation

struct MarketScanner: Sendable {
    let api: BinanceAPI

    init(api: BinanceAPI = .shared) {
        self.api = api
    }

    func scan(
        config: RadarConfig,
        includeLiveCandle: Bool,
        progress: @Sendable @escaping (Int, Int) async -> Void
    ) async throws -> [ScanResult] {
        let candidates = try await api.fetchCandidates(config: config)
        let semaphore = AsyncSemaphore(value: 8)
        let engine = BreakoutScoringEngine(config: config)
        let total = candidates.count

        return try await withThrowingTaskGroup(of: ScanResult?.self) { group in
            for ticker in candidates {
                group.addTask {
                    await semaphore.acquire()

                    do {
                        async let candles = api.fetchCandles(
                            symbol: ticker.symbol,
                            interval: config.klineInterval,
                            count: config.lookbackPeriods,
                            includeLiveCandle: includeLiveCandle
                        )
                        async let oi = api.fetchOpenInterestHistory(symbol: ticker.symbol, config: config)
                        let (candleRows, oiRows) = try await (candles, oi)
                        let result = engine.evaluate(
                            symbol: ticker.symbol,
                            candles: candleRows,
                            historicalOI: oiRows
                        )
                        await semaphore.release()
                        return result
                    } catch {
                        await semaphore.release()
                        return nil
                    }
                }
            }

            var results: [ScanResult] = []
            var completed = 0
            for try await result in group {
                completed += 1
                await progress(completed, total)
                guard let result, result.score >= config.displayMinimumScore else { continue }
                results.append(result)
            }
            return results.sorted {
                if $0.score == $1.score { return $0.deltaOI > $1.deltaOI }
                return $0.score > $1.score
            }
        }
    }
}
