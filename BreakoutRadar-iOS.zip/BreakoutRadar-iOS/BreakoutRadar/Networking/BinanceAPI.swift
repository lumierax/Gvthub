import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

actor BinanceAPI {
    static let shared = BinanceAPI()

    private let baseURL = URL(string: "https://fapi.binance.com")!
    private let session: URLSession
    private let decoder = JSONDecoder()

    init(session: URLSession = .shared) {
        self.session = session
    }

    func fetchCandidates(config: RadarConfig) async throws -> [CandidateTicker] {
        async let info: BinanceExchangeInfoResponse = get(path: "/fapi/v1/exchangeInfo")
        async let tickers: [BinanceTicker24h] = get(path: "/fapi/v1/ticker/24hr")

        let (exchangeInfo, tickerRows) = try await (info, tickers)
        let active = Set(exchangeInfo.symbols.compactMap { item -> String? in
            guard
                item.contractType == "PERPETUAL",
                item.quoteAsset == "USDT",
                item.status == "TRADING",
                !config.blacklist.contains(item.symbol)
            else { return nil }
            return item.symbol
        })

        // Scan every active USDT perpetual contract. Quote volume is used only
        // to order the work so the most liquid markets are evaluated first;
        // no symbol is discarded because of low volume or a top-N cap.
        return tickerRows
            .compactMap { ticker -> CandidateTicker? in
                guard active.contains(ticker.symbol) else { return nil }
                let volume = Double(ticker.quoteVolume) ?? 0
                return CandidateTicker(
                    symbol: ticker.symbol,
                    quoteVolume: volume,
                    priceChangePercent: Double(ticker.priceChangePercent) ?? 0,
                    lastPrice: Double(ticker.lastPrice) ?? 0
                )
            }
            .sorted { lhs, rhs in
                if lhs.quoteVolume == rhs.quoteVolume {
                    return abs(lhs.priceChangePercent) > abs(rhs.priceChangePercent)
                }
                return lhs.quoteVolume > rhs.quoteVolume
            }
    }

    func fetchCandles(
        symbol: String,
        interval: String,
        count: Int,
        includeLiveCandle: Bool
    ) async throws -> [Candle] {
        let requested = includeLiveCandle ? count : count + 1
        let query = [
            URLQueryItem(name: "symbol", value: symbol),
            URLQueryItem(name: "interval", value: interval),
            URLQueryItem(name: "limit", value: String(requested))
        ]
        let rows: [BinanceKline] = try await get(path: "/fapi/v1/klines", queryItems: query)
        let nowMillis = Int64(Date().timeIntervalSince1970 * 1000)

        var candles = rows.map { $0.candle }
        if !includeLiveCandle, let lastRow = rows.last, lastRow.closeTime > nowMillis {
            candles.removeLast()
        }
        return Array(candles.suffix(count))
    }

    func fetchOpenInterestHistory(symbol: String, config: RadarConfig) async throws -> [Double] {
        let query = [
            URLQueryItem(name: "symbol", value: symbol),
            URLQueryItem(name: "period", value: config.openInterestPeriod),
            URLQueryItem(name: "limit", value: String(config.openInterestLimit))
        ]
        let rows: [BinanceOpenInterestPoint] = try await get(
            path: "/futures/data/openInterestHist",
            queryItems: query
        )
        return rows.compactMap { Double($0.sumOpenInterestValue) }
    }

    private func get<T: Decodable>(
        path: String,
        queryItems: [URLQueryItem] = []
    ) async throws -> T {
        var components = URLComponents(url: baseURL.appendingPathComponent(path), resolvingAgainstBaseURL: false)
        components?.queryItems = queryItems.isEmpty ? nil : queryItems
        guard let url = components?.url else { throw APIError.invalidURL }

        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        request.setValue("BreakoutRadar-iOS/1.0", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        guard 200..<300 ~= http.statusCode else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw APIError.http(status: http.statusCode, body: body)
        }

        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decoding(error.localizedDescription)
        }
    }
}

enum APIError: LocalizedError {
    case invalidURL
    case invalidResponse
    case http(status: Int, body: String)
    case decoding(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "تعذر إنشاء رابط Binance."
        case .invalidResponse:
            return "استجابة الشبكة غير صالحة."
        case let .http(status, body):
            return "Binance أعاد HTTP \(status). \(body.prefix(120))"
        case let .decoding(message):
            return "تعذر قراءة بيانات Binance: \(message)"
        }
    }
}

private struct BinanceExchangeInfoResponse: Decodable {
    let symbols: [BinanceSymbolInfo]
}

private struct BinanceSymbolInfo: Decodable {
    let symbol: String
    let contractType: String
    let quoteAsset: String
    let status: String
}

private struct BinanceTicker24h: Decodable {
    let symbol: String
    let priceChangePercent: String
    let lastPrice: String
    let quoteVolume: String
}

private struct BinanceOpenInterestPoint: Decodable {
    let sumOpenInterestValue: String
}

private struct BinanceKline: Decodable {
    let openTime: Int64
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    let volume: Double
    let closeTime: Int64

    init(from decoder: Decoder) throws {
        var container = try decoder.unkeyedContainer()
        openTime = try container.decode(Int64.self)
        open = Double(try container.decode(String.self)) ?? 0
        high = Double(try container.decode(String.self)) ?? 0
        low = Double(try container.decode(String.self)) ?? 0
        close = Double(try container.decode(String.self)) ?? 0
        volume = Double(try container.decode(String.self)) ?? 0
        closeTime = try container.decode(Int64.self)
    }

    var candle: Candle {
        Candle(
            openTime: Date(timeIntervalSince1970: Double(openTime) / 1000),
            closeTime: Date(timeIntervalSince1970: Double(closeTime) / 1000),
            open: open,
            high: high,
            low: low,
            close: close,
            volume: volume
        )
    }
}
