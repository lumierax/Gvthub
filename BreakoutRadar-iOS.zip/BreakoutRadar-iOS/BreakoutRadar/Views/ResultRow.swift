import SwiftUI

struct ResultRow: View {
    let result: ScanResult
    let config: RadarConfig

    private var accent: Color {
        if result.score >= config.sniperScore { return .cyan }
        if result.score >= config.watchlistScore { return .green }
        return .orange
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 7) {
                        Text(result.displaySymbol)
                            .font(.title3.bold())
                        Text("/USDT")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Text(result.price.formattedPrice)
                        .font(.system(.body, design: .monospaced).weight(.semibold))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 5) {
                    Text(result.status(using: config))
                        .font(.caption2.bold())
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .foregroundStyle(accent)
                        .background(accent.opacity(0.12), in: Capsule())
                    Text(result.direction == .long ? "▲ LONG" : "▼ SHORT")
                        .font(.caption.bold())
                        .foregroundStyle(result.direction == .long ? .green : .red)
                }
            }

            HStack(spacing: 10) {
                ScoreBadge(score: result.score, color: accent)
                MetricBox(title: "VOL Z", value: String(format: "%.2f", result.zScore))
                MetricBox(title: "ΔOI", value: String(format: "%+.2f%%", result.deltaOI))
                MetricBox(title: "BBW", value: String(format: "%.3f", result.bbw))
            }

            if !result.flags.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(result.flags, id: \.self) { flag in
                            Text(flag)
                                .font(.caption2.weight(.semibold))
                                .padding(.horizontal, 7)
                                .padding(.vertical, 4)
                                .background(Color.secondary.opacity(0.12), in: Capsule())
                        }
                    }
                }
            }
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct ScoreBadge: View {
    let score: Int
    let color: Color

    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.16), lineWidth: 5)
            Circle()
                .trim(from: 0, to: CGFloat(min(max(score, 0), 100)) / 100)
                .stroke(color, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(-90))
            Text("\(score)")
                .font(.system(.caption, design: .rounded).bold())
        }
        .frame(width: 50, height: 50)
        .accessibilityLabel("Score \(score)")
    }
}

private struct MetricBox: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(.caption, design: .monospaced).weight(.semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private extension Double {
    var formattedPrice: String {
        if self >= 1_000 { return String(format: "$%.2f", self) }
        if self >= 1 { return String(format: "$%.4f", self) }
        if self >= 0.01 { return String(format: "$%.6f", self) }
        return String(format: "$%.8f", self)
    }
}
