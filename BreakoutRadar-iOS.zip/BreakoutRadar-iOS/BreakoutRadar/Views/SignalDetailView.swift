import SwiftUI

struct SignalDetailView: View {
    let result: ScanResult
    let config: RadarConfig

    private var accent: Color {
        result.score >= config.sniperScore ? .cyan : (result.score >= config.watchlistScore ? .green : .orange)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(spacing: 8) {
                    Text(result.displaySymbol + "/USDT")
                        .font(.largeTitle.bold())
                    Text(result.direction == .long ? "▲ LONG" : "▼ SHORT")
                        .font(.headline.bold())
                        .foregroundStyle(result.direction == .long ? .green : .red)
                    Text("Score \(result.score)/100")
                        .font(.title2.bold())
                        .foregroundStyle(accent)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)

                VStack(spacing: 0) {
                    DetailLine(title: "السعر", value: formatPrice(result.price))
                    Divider()
                    DetailLine(title: "Volume Z-Score", value: String(format: "%.3f", result.zScore))
                    Divider()
                    DetailLine(title: "Bollinger Bandwidth", value: String(format: "%.4f", result.bbw))
                    Divider()
                    DetailLine(title: "Open Interest Δ", value: String(format: "%+.3f%%", result.deltaOI))
                    Divider()
                    DetailLine(title: "حجم آخر شمعة", value: formatCompact(result.volume))
                }
                .padding(.horizontal)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))

                VStack(alignment: .leading, spacing: 12) {
                    Text("الإشارات المفعّلة")
                        .font(.headline)
                    if result.flags.isEmpty {
                        Text("لا توجد Flags إضافية.")
                            .foregroundStyle(.secondary)
                    } else {
                        FlowTags(flags: result.flags)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .leading, spacing: 10) {
                    Text("كيف تُحسب الإشارة")
                        .font(.headline)
                    explanationRow("COILED", "ضغط Bollinger خلال آخر 10 قراءات: +20")
                    explanationRow("VOL_SPIKE", "Volume Z-Score ≥ 3: +25")
                    explanationRow("OI_EXPANSION", "ارتفاع OI ≥ 2% بين آخر قراءتين: +15")
                    explanationRow("TREND", "SMA 7 متوافق مع اتجاه SMA 25: +15")
                    explanationRow("STRONG_BODY", "جسم شمعة ≥ 70% مع رفض سعري محدود: +15")
                    Text("إذا لم يكن السعر قرب قمة/قاع نطاق الـ50 شمعة، يخفض المحرك النتيجة إلى النصف.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))

                Text("هذه أداة تحليل وليست ضمانًا لحركة السعر أو الربح.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.top, 4)
            }
            .padding()
        }
        .navigationTitle(result.displaySymbol)
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder
    private func explanationRow(_ flag: String, _ explanation: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: result.flags.contains(flag) ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(result.flags.contains(flag) ? accent : .secondary)
            Text(explanation)
                .font(.subheadline)
        }
    }

    private func formatPrice(_ price: Double) -> String {
        if price >= 1 { return String(format: "$%.4f", price) }
        if price >= 0.01 { return String(format: "$%.6f", price) }
        return String(format: "$%.8f", price)
    }

    private func formatCompact(_ value: Double) -> String {
        if value >= 1_000_000_000 { return String(format: "%.2fB", value / 1_000_000_000) }
        if value >= 1_000_000 { return String(format: "%.2fM", value / 1_000_000) }
        if value >= 1_000 { return String(format: "%.2fK", value / 1_000) }
        return String(format: "%.2f", value)
    }
}

private struct DetailLine: View {
    let title: String
    let value: String

    var body: some View {
        HStack {
            Text(title)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .font(.system(.body, design: .monospaced).weight(.semibold))
        }
        .padding(.vertical, 12)
    }
}

private struct FlowTags: View {
    let flags: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(flags, id: \.self) { flag in
                HStack {
                    Image(systemName: "bolt.fill")
                        .foregroundStyle(.cyan)
                    Text(flag)
                        .font(.system(.subheadline, design: .monospaced).bold())
                }
            }
        }
    }
}
