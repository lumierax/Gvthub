import SwiftUI

struct SettingsView: View {
    @ObservedObject var model: RadarViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("المسح") {
                    Stepper("عدد العملات: \(model.maxSymbolsTracked)", value: $model.maxSymbolsTracked, in: 20...120, step: 20)
                    HStack {
                        Text("الحد الأدنى لحجم 24h")
                        Spacer()
                        Text("$\(model.minVolumeMillions, specifier: "%.0f")M")
                            .foregroundStyle(.secondary)
                    }
                    Slider(value: $model.minVolumeMillions, in: 1...100, step: 1)
                }

                Section("وضع الشمعة") {
                    Toggle("استخدم شمعة 15m الحالية", isOn: $model.includeLiveCandle)
                    Text(model.includeLiveCandle
                         ? "أسرع، لكنه أكثر ضوضاء لأن حجم الشمعة لم يكتمل بعد."
                         : "الوضع المطابق للمحرك: يستخدم آخر شمعة 15m مكتملة.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("التحديث") {
                    Toggle("تحديث تلقائي", isOn: $model.autoRefresh)
                    Text("عند فتح التطبيق يعاد الفحص كل 45 ثانية. iOS لا يضمن استمرار المسح عندما يكون التطبيق مغلقًا.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("المصدر") {
                    LabeledContent("السوق", value: "Binance USD-M Futures")
                    LabeledContent("الفريم", value: "15m")
                    LabeledContent("Lookback", value: "50 شمعة")
                }
            }
            .navigationTitle("الإعدادات")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("تم") {
                        model.applySettingsAndRescan()
                        dismiss()
                    }
                }
            }
        }
    }
}
