import SwiftUI

struct SettingsView: View {
    @ObservedObject var model: RadarViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("المسح") {
                    LabeledContent("النطاق", value: "جميع عقود USDT الدائمة")
                    Text("لا يوجد حد أعلى لعدد العملات ولا فلتر حد أدنى لحجم 24 ساعة. يتم ترتيب العملات بالحجم فقط لتحديد أولوية الفحص، ثم تُفحص جميعها.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("وضع الشمعة") {
                    Toggle("استخدم شمعة 15m الحالية", isOn: $model.includeLiveCandle)
                    Text(model.includeLiveCandle
                         ? "أسرع، لكنه أكثر ضوضاء لأن حجم الشمعة لم يكتمل بعد."
                         : "الوضع المطابق للمحرك: يستخدم آخر شمعة 15m مكتملة.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("التحديث") {
                    Toggle("تحديث تلقائي", isOn: $model.autoRefresh)
                    Text("عند فتح التطبيق يعاد الفحص كل 45 ثانية. iOS لا يضمن استمرار المسح عندما يكون التطبيق مغلقًا.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("المصدر") {
                    LabeledContent("السوق", value: "Binance USD-M Futures")
                    LabeledContent("الفريم", value: "15m")
                    LabeledContent("Lookback", value: "50 شمعة")
                }
            }
            .navigationTitle("الإعدادات")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("تم") {
                        model.applySettingsAndRescan()
                        dismiss()
                    }
                }
            }
        }
    }
}
