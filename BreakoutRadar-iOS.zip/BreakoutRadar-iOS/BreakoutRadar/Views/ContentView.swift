import SwiftUI

struct ContentView: View {
    @StateObject private var model = RadarViewModel()
    @State private var showingSettings = false
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        NavigationStack {
            ZStack {
                Color(uiColor: .systemBackground)
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    header
                    controls

                    if model.isScanning && model.results.isEmpty {
                        loadingState
                    } else if let error = model.errorMessage, model.results.isEmpty {
                        errorState(error)
                    } else if model.visibleResults.isEmpty {
                        emptyState
                    } else {
                        resultsList
                    }
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingSettings) {
                SettingsView(model: model)
            }
            .task {
                model.start()
            }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active {
                    model.start()
                } else if phase == .background {
                    model.stop()
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("BREAKOUT RADAR")
                        .font(.system(.title2, design: .rounded).weight(.black))
                        .foregroundStyle(.cyan)
                    Text("BINANCE USD-M • NATIVE iOS")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    showingSettings = true
                } label: {
                    Image(systemName: "slider.horizontal.3")
                        .font(.title3)
                        .frame(width: 42, height: 42)
                        .background(Color(uiColor: .secondarySystemBackground), in: Circle())
                }
            }

            HStack(spacing: 10) {
                SummaryCard(title: "SNIPER", value: model.sniperCount, tint: .cyan)
                SummaryCard(title: "WATCH", value: model.watchlistCount, tint: .green)
                SummaryCard(title: "FOUND", value: model.results.count, tint: .orange)
            }

            HStack {
                Label(statusText, systemImage: model.isScanning ? "waveform.path.ecg" : "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(model.isScanning ? .cyan : .secondary)
                Spacer()
                if let date = model.lastUpdated {
                    Text(date, style: .time)
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal)
        .padding(.top, 12)
        .padding(.bottom, 10)
    }

    private var controls: some View {
        VStack(spacing: 10) {
            Picker("الاتجاه", selection: $model.filter) {
                ForEach(ScanFilter.allCases) { filter in
                    Text(filter.rawValue).tag(filter)
                }
            }
            .pickerStyle(.segmented)

            HStack(spacing: 10) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("ابحث عن عملة", text: $model.searchText)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                }
                .padding(.horizontal, 12)
                .frame(height: 42)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))

                Button {
                    Task { await model.scanNow() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.headline)
                        .frame(width: 44, height: 42)
                        .background(Color.cyan.opacity(0.14), in: RoundedRectangle(cornerRadius: 12))
                }
                .disabled(model.isScanning)
            }
        }
        .padding(.horizontal)
        .padding(.bottom, 10)
    }

    private var resultsList: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                if let error = model.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.orange)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(10)
                        .background(Color.orange.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
                }

                ForEach(model.visibleResults) { result in
                    NavigationLink {
                        SignalDetailView(result: result, config: model.config)
                    } label: {
                        ResultRow(result: result, config: model.config)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 24)
        }
        .refreshable {
            await model.scanNow()
        }
    }

    private var loadingState: some View {
        VStack(spacing: 16) {
            Spacer()
            ProgressView(value: Double(model.scannedCount), total: Double(max(model.totalCount, 1)))
                .tint(.cyan)
                .padding(.horizontal, 48)
            Text("يفحص \(model.scannedCount) / \(model.totalCount)")
                .font(.headline.monospacedDigit())
            Text("تحميل الشموع وOpen Interest وحساب الإشارات...")
                .font(.footnote)
                .foregroundStyle(.secondary)
            Spacer()
        }
    }

    private var emptyState: some View {
        ContentUnavailableView(
            "لا توجد إشارة قوية الآن",
            systemImage: "radar",
            description: Text("جرّب تحديث المسح أو خفّض فلتر حجم 24 ساعة من الإعدادات.")
        )
    }

    private func errorState(_ message: String) -> some View {
        ContentUnavailableView {
            Label("تعذر الاتصال", systemImage: "wifi.exclamationmark")
        } description: {
            Text(message)
        } actions: {
            Button("إعادة المحاولة") {
                Task { await model.scanNow() }
            }
            .buttonStyle(.borderedProminent)
        }
    }

    private var statusText: String {
        if model.isScanning { return "SCANNING \(model.scannedCount)/\(model.totalCount)" }
        if model.autoRefresh { return "LIVE • AUTO 45s" }
        return "READY"
    }
}

private struct SummaryCard: View {
    let title: String
    let value: Int
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption2.bold())
                .foregroundStyle(.secondary)
            Text("\(value)")
                .font(.title3.monospacedDigit().bold())
                .foregroundStyle(tint)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}
