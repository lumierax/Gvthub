import SwiftUI

@main
struct BreakoutRadarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
