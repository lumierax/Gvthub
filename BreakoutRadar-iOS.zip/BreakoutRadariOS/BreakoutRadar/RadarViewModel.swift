import Foundation
import SwiftUI

@MainActor
final class RadarViewModel: ObservableObject {
    @Published var candidates: [Candidate] = []
    @Published var status = "SYSTEM READY"
    @Published var countdown = 0
    @Published var weight = 0
    @Published var scannedSymbols = 0
    @Published var totalSymbols = 0

    private let client = BinanceClient()
    private var task: Task<Void, Never>?

    var scanProgress: Double {
        guard totalSymbols > 0 else { return 0 }
        return Double(scannedSymbols) / Double(totalSymbols)
    }

    func start() {
        guard task == nil else { return }
        task = Task { await loop() }
    }

    func stop() {
        task?.cancel()
        task = nil
    }

    private func loop() async {
        let scanner = MarketScanner(client: client)

        while !Task.isCancelled {
            scannedSymbols = 0
            totalSymbols = 0
            status = "SCANNING ALL MARKETS..."

            do {
                let res = try await scanner.run { [weak self] done, total in
                    guard let self else { return }
                    self.scannedSymbols = done
                    self.totalSymbols = total
                    self.status = "SCANNING ALL MARKETS  \(done)/\(total)"
                }
                candidates = res
                status = "FULL SCAN COMPLETE • \(res.count) QUALIFIED"
            } catch {
                status = "NETWORK ERROR - RETRYING"
            }

            weight = await client.usedWeight

            // A full-market pass can take longer than the old top-40 scan.
            // Start the next pass after the normal refresh delay; MarketScanner
            // itself pauses whenever Binance's rolling request budget is high.
            var i = Config.refreshSeconds
            while i > 0 {
                if Task.isCancelled { return }
                countdown = i
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                i -= 1
            }
            countdown = 0
        }
    }
}
