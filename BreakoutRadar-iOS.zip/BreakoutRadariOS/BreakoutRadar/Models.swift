import Foundation

enum Config {
    // Scan every active USDT perpetual contract returned by Binance.
    // Activity is used only to decide scan order; it never excludes a symbol.
    static let refreshSeconds = 45
    static let maxConcurrent = 6

    // Stay comfortably below Binance's rolling request-weight limit.
    // When this level is reached during a full-market scan, the scanner pauses
    // and then continues from the same symbol instead of dropping the rest.
    static let weightSoftLimit = 900
    static let weightCooldownSeconds = 65

    static let displayMin = 25
}

struct Candidate: Identifiable, Equatable {
    var id: String { symbol }
    let symbol: String
    let price: Double
    let score: Int
    let zScore: Double
    let bbw: Double
    let change24h: Double
    let flags: [String]

    var label: String {
        score > 80 ? "SNIPER ENTRY" : (score > 60 ? "WATCHLIST" : "NO TRADE")
    }
}

struct Kline {
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    let volume: Double
}

struct Ticker24h: Decodable {
    let symbol: String
    let lastPrice: String
    let priceChangePercent: String
    let quoteVolume: String
}

struct ExchangeInfo: Decodable {
    struct Sym: Decodable {
        let symbol: String
        let contractType: String
        let quoteAsset: String
        let status: String
    }
    let symbols: [Sym]
}

struct OpenInterestResponse: Decodable {
    let openInterest: String
}
