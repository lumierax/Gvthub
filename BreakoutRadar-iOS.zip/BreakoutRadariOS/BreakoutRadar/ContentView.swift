import SwiftUI

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255)
    }
}

struct ContentView: View {
    @StateObject private var vm = RadarViewModel()

    var body: some View {
        ZStack {
            Color(hex: 0x0B0E11).ignoresSafeArea()
            VStack(spacing: 0) {
                header
                List(vm.candidates) { c in
                    RowView(c: c)
                        .listRowBackground(Color.clear)
                        .listRowSeparatorTint(Color(hex: 0x1E2329))
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                Text("■ >80 SNIPER   ■ >60 WATCHLIST   ■ <60 NO TRADE")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(Color(hex: 0x555B66))
                    .padding(.vertical, 8)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            vm.start()
            UIApplication.shared.isIdleTimerDisabled = true
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("BREAKOUT /// RADAR")
                    .font(.system(size: 13, weight: .black))
                    .tracking(2)
                    .foregroundColor(Color(hex: 0x00F0FF))
                Spacer()
                if vm.countdown > 0 {
                    Text("NEXT \(vm.countdown)s")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundColor(Color(hex: 0x00F0FF))
                }
            }
            Text(vm.status)
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(Color(hex: 0x777D88))
            if vm.totalSymbols > 0 {
                ProgressView(value: vm.scanProgress)
                    .tint(Color(hex: 0x00F0FF))
                Text("ALL USD-M USDT PERPETUALS • \(vm.scannedSymbols)/\(vm.totalSymbols)")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundColor(Color(hex: 0x555B66))
            }
            ProgressView(value: Double(min(vm.weight, 1200)), total: 1200)
                .tint(vm.weight < 500 ? Color(hex: 0x00F0FF) : (vm.weight < 800 ? Color(hex: 0xFFD700) : Color(hex: 0xFF0055)))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }
}

struct RowView: View {
    let c: Candidate

    private var scoreColor: Color {
        c.score > 80 ? Color(hex: 0x00FFFF) : (c.score > 60 ? Color(hex: 0x00FF66) : Color(hex: 0x888888))
    }

    private func flagColor(_ f: String) -> Color {
        switch f {
        case "VOL_SPIKE": return Color(hex: 0x00FFFF)
        case "COILED": return Color(hex: 0xFF00FF)
        case "MOMENTUM": return Color(hex: 0x0ECB81)
        case "REJECTION": return Color(hex: 0xFF0055)
        default: return Color(hex: 0xFFD700)
        }
    }

    private func fmt(_ p: Double) -> String {
        p < 10 ? String(format: "%.4f", p) : String(format: "%.2f", p)
    }

    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 5) {
                Text(c.symbol.replacingOccurrences(of: "USDT", with: ""))
                    .font(.system(.headline, design: .monospaced))
                    .foregroundColor(.white)
                Text(fmt(c.price))
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(Color(hex: 0xB7BDC6))
                HStack(spacing: 4) {
                    ForEach(c.flags, id: \.self) { f in
                        Text(f)
                            .font(.system(size: 9, weight: .bold))
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(flagColor(f).opacity(0.18))
                            .foregroundColor(flagColor(f))
                            .cornerRadius(4)
                    }
                }
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 3) {
                Text("\(c.score)")
                    .font(.system(size: 26, weight: .black, design: .rounded))
                    .foregroundColor(scoreColor)
                Text(c.label)
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(scoreColor)
                Text(String(format: "Z %.1f · BBW %.3f · %+.1f%%", c.zScore, c.bbw, c.change24h))
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(Color(hex: 0x848E9C))
            }
        }
        .padding(.vertical, 4)
    }
}
