import Foundation

actor BinanceClient {
    private let base = "https://fapi.binance.com"
    private let session: URLSession
    private(set) var usedWeight = 0

    init() {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 10
        cfg.httpAdditionalHeaders = ["User-Agent": "BreakoutRadar-iOS/1.0"]
        session = URLSession(configuration: cfg)
    }

    private func get(_ path: String, query: [URLQueryItem] = []) async throws -> Data {
        var comps = URLComponents(string: base + path)!
        if !query.isEmpty { comps.queryItems = query }
        let (data, resp) = try await session.data(from: comps.url!)
        if let http = resp as? HTTPURLResponse {
            if let w = http.value(forHTTPHeaderField: "X-MBX-USED-WEIGHT-1M"), let v = Int(w) {
                usedWeight = v
            }
            if http.statusCode != 200 { throw URLError(.badServerResponse) }
        }
        return data
    }

    func activeSymbols() async throws -> [String] {
        let data = try await get("/fapi/v1/exchangeInfo")
        let info = try JSONDecoder().decode(ExchangeInfo.self, from: data)
        return info.symbols
            .filter { $0.contractType == "PERPETUAL" && $0.quoteAsset == "USDT" && $0.status == "TRADING" }
            .map { $0.symbol }
    }

    func tickers() async throws -> [Ticker24h] {
        let data = try await get("/fapi/v1/ticker/24hr")
        return try JSONDecoder().decode([Ticker24h].self, from: data)
    }

    func klines(_ symbol: String, interval: String, limit: Int) async throws -> [Kline] {
        let data = try await get("/fapi/v1/klines", query: [
            URLQueryItem(name: "symbol", value: symbol),
            URLQueryItem(name: "interval", value: interval),
            URLQueryItem(name: "limit", value: String(limit))
        ])
        let rows = (try JSONSerialization.jsonObject(with: data) as? [[Any]]) ?? []
        return rows.compactMap { r in
            guard r.count > 5,
                  let o = Double(r[1] as? String ?? ""),
                  let h = Double(r[2] as? String ?? ""),
                  let l = Double(r[3] as? String ?? ""),
                  let c = Double(r[4] as? String ?? ""),
                  let v = Double(r[5] as? String ?? "") else { return nil }
            return Kline(open: o, high: h, low: l, close: c, volume: v)
        }
    }

    func openInterest(_ symbol: String) async throws -> Double {
        let data = try await get("/fapi/v1/openInterest", query: [URLQueryItem(name: "symbol", value: symbol)])
        let r = try JSONDecoder().decode(OpenInterestResponse.self, from: data)
        return Double(r.openInterest) ?? 0
    }
}
