import Foundation

struct MarketScanner {
    let client: BinanceClient

    private struct Item {
        let symbol: String
        let change: Double
        let activityRank: Double
    }

    /// Scans *all* active Binance USD-M USDT perpetual contracts.
    /// The rank only controls which symbols are scanned first; nothing is cut off.
    func run(progress: (@MainActor @Sendable (Int, Int) -> Void)? = nil) async throws -> [Candidate] {
        let symbols = try await client.activeSymbols()
        let tickers = try await client.tickers()
        let tickerMap = Dictionary(tickers.map { ($0.symbol, $0) }, uniquingKeysWith: { a, _ in a })

        // Include every active symbol. Volume and 24h change are used only to
        // prioritize likely-active markets so interesting symbols appear sooner.
        var items: [Item] = symbols.map { symbol in
            let ticker = tickerMap[symbol]
            let volume = Double(ticker?.quoteVolume ?? "") ?? 0
            let change = Double(ticker?.priceChangePercent ?? "") ?? 0
            return Item(symbol: symbol,
                        change: change,
                        activityRank: volume * max(abs(change), 0.01))
        }
        items.sort { $0.activityRank > $1.activityRank }

        let total = items.count
        await progress?(0, total)

        var results: [Candidate] = []
        var start = 0
        var processed = 0

        while start < items.count {
            if Task.isCancelled { break }

            // Do not abandon low-volume / lower-ranked coins when Binance's
            // request budget gets tight. Pause, then resume the same full scan.
            let currentWeight = await client.usedWeight
            if currentWeight >= Config.weightSoftLimit {
                try? await Task.sleep(nanoseconds: UInt64(Config.weightCooldownSeconds) * 1_000_000_000)
                if Task.isCancelled { break }
            }

            let end = min(start + Config.maxConcurrent, items.count)
            let batch = Array(items[start..<end])
            start = end

            let found: [Candidate] = await withTaskGroup(of: Candidate?.self) { group in
                for item in batch {
                    group.addTask {
                        await self.evaluate(item.symbol, change: item.change)
                    }
                }

                var out: [Candidate] = []
                for await result in group {
                    if let result { out.append(result) }
                }
                return out
            }

            results += found
            processed += batch.count
            await progress?(processed, total)
        }

        return results.sorted { lhs, rhs in
            if lhs.score == rhs.score { return lhs.change24h > rhs.change24h }
            return lhs.score > rhs.score
        }
    }

    private func sma(_ values: [Double], _ period: Int) -> Double {
        let sample = values.suffix(period)
        return sample.isEmpty ? 0 : sample.reduce(0, +) / Double(sample.count)
    }

    private func evaluate(_ symbol: String, change: Double) async -> Candidate? {
        guard let h1 = try? await client.klines(symbol, interval: "1h", limit: 60),
              let m15 = try? await client.klines(symbol, interval: "15m", limit: 3),
              h1.count >= 50,
              let live = m15.last else { return nil }

        let n = h1.count
        let closes = h1.map { $0.close }
        let vols = h1.map { $0.volume }
        var score = 0
        var flags: [String] = []

        // 1) Volume Z-Score: last closed 1h candle vs previous 48
        let window = Array(vols[(n - 50)..<(n - 2)])
        let mean = window.reduce(0, +) / Double(window.count)
        let sd = sqrt(window.map { pow($0 - mean, 2) }.reduce(0, +) / Double(window.count))
        let z = sd > 0 ? (vols[n - 2] - mean) / sd : 0

        // Zombie filter is based on the symbol's own historical activity, not a
        // market-wide minimum-volume cutoff. This keeps the scan universal while
        // avoiding meaningless dead contracts.
        let last4 = vols[(n - 5)..<(n - 1)].reduce(0, +)
        if mean > 0 && last4 < 0.10 * mean * 4 { return nil }

        if z > 3.0 {
            score += 25
            flags.append("VOL_SPIKE")
        } else if z > 1.5 {
            score += 10
        }

        // 2) Bollinger Band Width (20) squeeze
        let last20 = Array(closes.suffix(20))
        let m20 = last20.reduce(0, +) / 20
        let sd20 = sqrt(last20.map { pow($0 - m20, 2) }.reduce(0, +) / 20)
        let bbw = m20 > 0 ? (4 * sd20) / m20 : 1
        if bbw < 0.03 {
            score += 20
            flags.append("COILED")
        }

        // 3) Live 15m candle
        let price = live.close
        let range = live.high - live.low
        if range > 0 && live.open > 0 {
            let body = abs(live.close - live.open) / range
            let move = (live.close - live.open) / live.open
            let upperWick = (live.high - max(live.open, live.close)) / range
            if body > 0.70 && move > 0.005 {
                score += 15
                flags.append("MOMENTUM")
            }
            if upperWick > 0.60 {
                score -= 30
                flags.append("REJECTION")
            }
        }

        // 4) Trend alignment
        let trendUp = sma(closes, 7) > sma(closes, 25)
        if trendUp {
            score += 15
        } else if change > 5.0 {
            score -= 10
        }

        // 5) Proximity to 48h high
        let high48 = h1.suffix(48).map { $0.high }.max() ?? price
        if high48 > 0 && price >= high48 * 0.99 {
            score += 10
            flags.append("ATH_NEAR")
        }

        // 6) Open interest (only for promising candidates, to conserve API weight)
        if score > 30,
           let oi = try? await client.openInterest(symbol),
           oi > 0 {
            score += 10
        }

        score = max(0, min(100, score))
        guard score > Config.displayMin else { return nil }

        return Candidate(symbol: symbol,
                         price: price,
                         score: score,
                         zScore: z,
                         bbw: bbw,
                         change24h: change,
                         flags: flags)
    }
}
